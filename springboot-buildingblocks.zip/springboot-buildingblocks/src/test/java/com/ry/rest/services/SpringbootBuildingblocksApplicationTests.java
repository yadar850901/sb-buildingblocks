package com.ry.rest.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBuildingblocksApplicationTests {

	@Test
	void contextLoads() {
	}

}
